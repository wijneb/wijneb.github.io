#!/bin/sh

echo "hello from inside the container"
