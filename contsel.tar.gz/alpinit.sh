#!/bin/sh

apk update
apk upgrade
apk add nano xterm \
  font-terminus font-awesome \
  font-dejavu openbox firefox-esr \
  icu-data-full firefox-esr-intl \
  pcmanfm mousepad xrandr python3 \
  xfce4-terminal feh dbus py3-pip \
  dbus-x11 xf86-video-fbdev xdotool \
  lightdm-gtk-greeter geckodriver curl

rc-update add lightdm 
rc-update add dbus 

cd /home/bw/
echo "exec openbox-session" > .xinitrc 
cp -R /etc/xdg/openbox .config/openbox

mkdir sel
cd sel
python -m venv myenv
source myenv/bin/activate
pip install selenium

chown -R bw:bw /home/bw

#add firefox location to pyscript
#options = FirefoxOptions()
#options.add_argument("--headless")
#options.add_argument("--kiosk")  # Enables full-screen mode
#options.binary_location = r'/usr/bin/firefox-esr'  

#doas apk add firefox-esr icu-data-full firefox-esr-intl
#doas apk add --upgrade $(apk search -q xf86-video*)
#doas apk add --no-cache $(apk search -q firefox-esr)
#/etc/lightdm/lightdm.conf autologin user=bw & session=openbox
#chmod +x bwalldias98.sh bwalldiasfun3.sh bwfirst98.sh
#put mycron in /etc/periodic/15min
#put sh bw1autostart.sh in ~/.config/openbox/autostart
#echo disable_overscan=1 >> /boot/usercfg.txt
#dpmsoff is xset +dpms in bwfirst98.sh




