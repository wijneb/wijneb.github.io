
import os
import time
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium import webdriver

picx = os.getenv('PICX')
urlx = os.getenv('URLX')
wdth = os.getenv('WIDTH')
hght = os.getenv('HEIGHT')

#print(f'PICX: {picx}')
#print(f'URLX: {urlx}')

options = FirefoxOptions()
options.add_argument("--headless")
options.add_argument("--kiosk")  # Enables full-screen mode

service = FirefoxService(executable_path='/usr/bin/geckodriver')
driver = webdriver.Firefox(service=service, options=options)
driver.set_window_size(wdth, hght)
driver.get(urlx)

time.sleep(7)  # Wait for 7 seconds
driver.save_screenshot(picx)
driver.quit()

