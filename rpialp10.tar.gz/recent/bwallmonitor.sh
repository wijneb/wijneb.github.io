#!/bin/sh

# Dit script monitored vanuit een cronjob elke 15 min bwalldias.sh op voortgang en neemt actie indien errors

oldini=$(cat inifile) 
Delays=$(echo "$oldini" | grep GENER | awk -F= '{print $2}')

mydate()       { date +"%b %d %H:%M" ; }
timetominutes(){ time=$1; echo $((10#${time:0:2} * 60 + 10#${time:3:2})); }

startdiashow() {
    if !(pgrep -x "feh") > /dev/null; then
        feh --fullscreen --slideshow-delay $Delays -R 60 pics &
        xdotool mousemove $WIDTH $HEIGHT # muis rechtsonder
    fi
}



# check if feh is alive and if not start it


# check of process pgrep -f "sh bwalldias" 


# check date en time progress (en grootte) pics (between 8 and 22 hours) en fill pics with backup if empty


# check progress in mylog file (awk current date and current hour != 23 time diff) in last entries)


# check RAM gebruik ( beneden 2 MB? )


