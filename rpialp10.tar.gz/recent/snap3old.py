import os
import sys
import time
import logging
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.support.ui import WebDriverWait

# Get environment variables
picx = os.getenv('PICX')
urlx = os.getenv('URLX')
wdth = os.getenv('WIDTH')
hght = os.getenv('HEIGHT')

# Set up logging for the script
logging.basicConfig(filename='/home/bw/sel/selenium.log', level=logging.DEBUG)

# Set up Firefox options
options = FirefoxOptions()
options.headless = True  # Enable headless mode
options.add_argument("--kiosk")  # Enable full-screen mode
options.log.level = "trace"  # Enable detailed geckodriver logging

# Set up Firefox service with log path for geckodriver
service = FirefoxService(executable_path='/usr/bin/geckodriver', log_path="/home/bw/sel/geckodriver.log")

try:
    # Initialize the Firefox WebDriver with options and service
    logging.info("Initializing Firefox WebDriver.")
    driver = webdriver.Firefox(service=service, options=options)
    logging.info("Firefox WebDriver initialized.")
    
    # Set the window size
    driver.set_window_size(int(wdth), int(hght))  # Ensure wdth and hght are integers
    logging.info(f"Window size set to {wdth}x{hght}.")

    # Define a custom expected condition for page load
    class PageLoaded:
        def __init__(self, driver):
            self.driver = driver

        def __call__(self, driver):
            return self.driver.execute_script("return document.readyState") == "complete"

    # Navigate to the specified URL and wait for the page to load
    driver.get(urlx)
    WebDriverWait(driver, 7).until(PageLoaded(driver))

    # Add an extra sleep period to ensure the page is fully rendered
    time.sleep(7)

    # Take a screenshot and save it to the specified location
    driver.save_screenshot(picx)
    logging.info("Screenshot taken successfully.")

except (TimeoutException, WebDriverException) as e:
    # Handle exceptions and log errors
    logging.error(f"Error during browser operation: {e}")
    sys.exit(1)  # Exit with a non-zero status to indicate an error

finally:
    # Quit the WebDriver
    driver.quit()
    logging.info("Browser closed.")
