#!/bin/bash

reboot

#source /home/bw/sel/venv/bin/activate

#source /home/bw/sel/bwalldiasfun3.sh
#pip show selenium
#loc=/home/bw/sel
#python test.py >> /home/bw/sel/cronjob.log 2>&1

#pytrm=$(cat /home/bw/sel/snap.py)
#URLX="https://tm-short.me/77wP26z"
#PICX="/home/bw/sel/pics2/Trackman_longest_30_dagen.png"
#export URLX; export PICX

#snapTrm(){ echo "$pytrm" | python - >> /home/bw/sel/cronjob.log ; }

#snapTrm


#export PATH=$PATH:/usr/bin:/bin:/usr/local/bin
#export DISPLAY=:0
#export XAUTHORITY=/home/bw/.Xauthority
#dpmsoff

