
import os
import sys
import time
import logging
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.support.ui import WebDriverWait

picx = os.getenv('PICX')
urlx = os.getenv('URLX')
wdth = os.getenv('WIDTH')
hght = os.getenv('HEIGHT')

#wdth=1920
#hgth=1080

logging.basicConfig(filename='/home/bw/sel/selenium.log', level=logging.DEBUG)

options = FirefoxOptions()
options.add_argument("--headless")
options.add_argument("--kiosk")  # Enables full-screen mode

options.log.level = "trace"  # Enable detailed geckodriver logging

service = FirefoxService(executable_path='/usr/bin/geckodriver')

driver = webdriver.Firefox(service=service, options=options)

# driver = webdriver.Firefox(options=options, service_log_path="/home/bw/sel/geckodriver.log")

driver.set_window_size(wdth, hght)
logging.info("Browser started successfully.")

# Define a custom expected condition
class PageLoaded:
    def __init__(self, driver):
        self.driver = driver

    def __call__(self, driver):
        return self.driver.execute_script("return document.readyState") == "complete"

try:
    driver.get(urlx)
    
    # Wait for the page to load with a timeout of 7 seconds
    WebDriverWait(driver, 7).until(PageLoaded(driver))

    # Add an extra sleep period to ensure the page is fully rendered 
    time.sleep(7)

    # Take a screenshot only when succesfull cq when no exception
    driver.save_screenshot(picx)
    # print("from py: Screenshot taken successfully.")

except (TimeoutException, WebDriverException) as e:
    # Handle the exception and gracefully exit the script
    logging.error(f"Error starting browser: {e}")
    print(f"py trm not ok {e}")
    sys.exit(1)  # Exit with a non-zero status to indicate an error

finally:
    driver.quit()
