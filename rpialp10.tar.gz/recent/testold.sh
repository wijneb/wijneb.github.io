#!/bin/sh

cd /home/bw/sel

export DISPLAY=:0
xrandr 2>/dev/null | grep "0.00" | awk -Fx '{print $1}' 

#sh myfirst98.sh >> mylog

#sh bwalldias98.sh >> mylog

#sleep 360
#sh myfirst98.sh >> mylog
#sh bwalldias98.sh >> mylog



# sh mycronjob.sh >> monlog2

#!/bin/sh

# Set the DISPLAY and XAUTHORITY variables
export DISPLAY=:0
export XAUTHORITY=/home/bw/.Xauthority


# Run xrandr and set environment variables
WIDTH=$(xrandr 2>/dev/null | grep "0.00" | awk -Fx '{print $1}')
HEIGHT=$(xrandr 2>/dev/null | grep "0.00" | awk -Fx '{print $2}' | awk '{print $1}')

HEIGHT=$((HEIGHT+1-1))
WIDTH=$((WIDTH+1-1))

# Debugging: print the values to verify
echo "WIDTH=$WIDTH"
echo "HEIGHT=$HEIGHT"




