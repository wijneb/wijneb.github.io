#!/bin/sh

cd /home/bw/sel
loc="/home/bw/sel"
lg1="$loc/delpics"
PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

source /home/bw/sel/bwalldiasfun3.sh                # import benodigde sh functies
source /home/bw/sel/venv/bin/activate               # activeer python virt env

mydate1(){ date +%S ; }

gethd1()      { R=""; inisiteok;trmsiteok;egfsiteok; [ -z "$R" ]  && mymsg "no sites" && statusFalse || echo "$R"; }

egfurl="https://leeuwenbergh.e-golf4u.nl"

main() { 
  echo "$(mydate1) inisetup"
  inisetup               # set environment vars
  echo "$(mydate1) checksunset"
  checksunset            # what is the sunset time
  # msgsunset            # only after reboot show sunset timebwalldias98.sh
  # boottimemsg            # msg shown only after boot
  # newline                # start at newline at the hour or after 9 entries on a line
  echo "$(mydate1) gethd"
  gethd | grep date
  #echo "$(mydate1) datetime"
  #datetime
  #echo "$(mydate1) hdtdati"
  #(hdrdati; echo "$hdrdate")
  #echo "$(mydate1) datimsg"
  #datimsg
  #checkall               # check trm/egf/ini/clock/date&time c1c2c3c4c5
  #readinifle            # try and read old or new inifile
  #alldias                # try and take snapshots from trm and egf sites
  } 

main1() { 
  echo "$(mydate1) inisetup"
  inisetup               # set environment vars
  echo "$(mydate1) checksunset"
  checksunset            # what is the sunset time
  echo "$(mydate1) gethd1"
  egfsiteok; echo "$R" | grep -i ^date
  inisiteok; echo "$R" | grep -i ^date
  trmsiteok; echo "$R" | grep -i ^date
  #gethd1 | grep date
  } 

main1

