#!/bin/sh

cd /home/bw/sel
loc="/home/bw/sel"
ADPS="CronDias"
kADP="killed CronDias process" 

PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

devnull() { "$@" > /dev/null 2>&1 ; }

getWH() { eval $( xrandr 2>&1 | grep "0.00" | awk -Fx '{print "WIDTH="int($1) "\nHEIGHT="int($2)}' ) ; }  

setEnv(){ export DISPLAY=:0; export XAUTHORITY=/home/bw/.Xauthority; }

mymsg()         { echo "$(date +"%b %d %H:%M") $1 " ; }

myreboot()      { mymsg "reboot in 1 min" ; sleep 60; reboot ; }

checkreboot()   { [ $(date +%-H) -eq 8 ] && [ $(date +%-M) -eq 0 ] && myreboot ; }

checkprevious() { devnull pgrep -f $ADPS || (pkill -f $ADPS && mymsg $kADP) ; }

atruntime()     { [ $(date +"%-H") -ge 8 ] && [ $(date +"%-H") -lt 23 ] && echo true || echo false; }

getDelays()     { Delays=$(cat $loc/inifile | grep GENER | awk -F= '{print $2}') ; }

startFeh()      { feh --fullscreen --slideshow-delay $Delays -R 60 pics 2>> monlog & }

moveMouse()     { /usr/bin/xdotool mousemove $WIDTH $HEIGHT ; } # muis rechtsonder

startdiashow()  { devnull pgrep -x feh || ( $(atruntime) && getWH && 
                  getDelays && startFeh && moveMouse && mymsg "started diashow from myfirst98" ) ; }

nodpms()        { dpmsoff ; } 

nofeh()         { devnull pgrep -x feh && pkill -x feh ; }

orstopdiashow() { devnull [ $(date +%-H) -eq 23 ] && [ $(date +%-M) -eq 15 ] && nofeh && dpmsoff ; return 0; }

main()          { setEnv; checkreboot; checkprevious; startdiashow; orstopdiashow; }

main


