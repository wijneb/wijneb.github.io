#!/bin/sh

# opstart files, opstarten vanaf OBautostart

mydate()   { date +%d%b%H:%M ; }

# Disable screensaver, blanking and power management (DPMS)
bootMsg()  { echo "$(mydate) just rebooted, this msg is from OBautostart" ; }
atBoot()   { xset s off ; xset s noblank ; xset -dpms ; bootMsg; }

startFeh() { Delays=$( cat inifile | grep GENER | cut -d= -f2 )
             feh --fullscreen --slideshow-delay $Delays -R 60 pics 2>> bwLogs/monlog & }

getRes()   { resFile=$(cat scrRes); Res=$(echo $(xrandr 2>&1 | tail -n 1) | cut -d' ' -f1); } # 1920x1080
setScrRes(){ getRes; [ $? -ne 0 ] || [ "$resFile" = "$Res" ] || echo "$Res" > scrRes ; }

changeIni(){ [ "$oldini" = "$newini" ] || [ "$newini" = "" ] || setIni ; }
setIni()   { echo "$oldini" > buInifiles/$(mydate)inifile; echo "$newini" > inifile ; }
readIni()  { oldini=$(cat inifile); iniurl="https://www.leeuwenbergh.nl/infoscreens/hal_1.ini"
             newini=$( curl -s --max-time 5 $iniurl 2> /dev/null | dos2unix ); xexit=$?
             [ $xexit -eq 0 ] && changeIni ; }

main()     { atBoot; startFeh; setScrRes; readIni; }

main

