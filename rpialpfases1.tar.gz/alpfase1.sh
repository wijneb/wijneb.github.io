#!/bin/sh

 if rc-service chronyd status | grep -q "started"
    then echo "chronyd is started correctly"
    else rc-service chronyd restart; sleep 5
 fi

MY_GIT1=https://raw.githubusercontent.com/wijneb/wijneb.github.io/main
MY_GIT2=https://raw.githubusercontent.com/wijneb/backgrounds/main/backgrounds

cat <<EOF > /boot/usercfg.txt
# Disable compensation for displays with overscan
disable_overscan=1
EOF

cat <<EOF > /etc/apk/repositories
https://dl-cdn.alpinelinux.org/alpine/edge/main
https://dl-cdn.alpinelinux.org/alpine/edge/community
https://dl-cdn.alpinelinux.org/alpine/edge/testing
EOF

apk update && apk upgrade && apk add \
openbox xterm font-terminus font-awesome font-dejavu ncdu \
xfce4-terminal mousepad pcmanfm xrandr feh htop xset xdotool \
firefox

cp -r /etc/xdg/openbox /home/bw/.config

setup-xorg-base
apk add xf86-video-fbdev

cat <<EOF >> /home/bw/.config/openbox/autostart
# Disable screensaver and blanking
xset s off
xset s noblank
# Disable power management (DPMS)
xset -dpms
EOF

curl -s "$MY_GIT2/0198.jpg" > /home/bw/.background.jpg
curl -s "$MY_GIT1/rcbu.xml" > /home/bw/.config/openbox/rc.xml
echo feh --bg-scale '/home/bw/.background.jpg'  >> /home/bw/.xinitrc
echo 'exec openbox-session' >> /home/bw/.xinitrc

cat <<EOF >> /home/bw/.profile
if [ -z "$DISPLAY" ] && [ -z "$SSH_TTY" ]; then
    exec startx
fi
EOF

# lets add gclwb network
cat <<EOF >> /etc/wpa_supplicant/wpa_supplicant.conf
network={
        ssid="gclwb"
        psk="49573845ccFa"
        id_str="lwb"
}
EOF

# if you want to switchoff the screen use dpmsoff cmd
cat <<EOF > /usr/local/bin/dpmsoff
#!/bin/sh
DISPLAY=:0.0 xset dpms force off
EOF
chmod +x /usr/local/bin/dpmsoff

chown -R bw:bw /home/bw





