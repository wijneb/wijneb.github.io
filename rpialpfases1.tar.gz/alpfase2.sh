#!/bin/sh

#lets make autologin happen.

apk update && apk add agetty

var1="getty 38400 tty1"
var2="agetty --autologin bw tty1 linux"
sed -i "s/$var1/$var2/g" /etc/inittab

cd /etc/init.d && ln -s agetty agetty.tty1.
cd /etc/conf.d && cp agetty agetty.tty1.

echo "/bin/login -f bw" > /usr/sbin/autologin
chmod +x /usr/sbin/autologin

# Define cron job1
#CRON_JOB1="0 22 * * * /usr/local/bin/dpmsoff"
# Add the cron job to the crontab
#(crontab -l; echo "$CRON_JOB1") | crontab

# Define cron job2
#CRON_JOB2="0 8 * * * /sbin/reboot"
# Add the cron job to the crontab
#(crontab -l; echo "$CRON_JOB2") | crontab 

