
#!/bin/sh

url1=https://trackman.page.link/ERdao;  pic1=pics/longest7dagen.png;   time=20;
url2=https://trackman.page.link/95pmR;  pic2=pics/longest30dagen.png;  time2=20;
url3=https://trackman.page.link/X31Rw;  pic3=pics/bullseye7dagen.png;  time3=20;
url4=https://trackman.page.link/daXw2;  pic4=pics/bullseye30dagen.png; time4=20;

WIDTH=xrandr | awk '/\*\+/ {print $1}'| awk -Fx '{print $1}'
HEIGHT=xrandr | awk '/\*\+/ {print $1}'| awk -Fx '{print $2}'
export WIDTH
export HEIGHT

source /home/bw/sel/venv/bin/activate

makedia() {
    python snap.py
}

alldias() {
    for i in $(seq 4); do
        eval URLX=\$url$i
        eval PICX=\$pic$i
        export URLX
        export PICX
        makedia
    done
}

main() {
    feh --fullscreen --slideshow-delay 5 -R 20 pics &
    while true; do
        alldias
        sleep 300
    done
}

main

