#!/bin/sh
rc-service chronyd restart


# doas ./retime.sh   without passwd
# permit nopass bw cmd ./retime.sh   in /etc/doas.d/doas.conf
