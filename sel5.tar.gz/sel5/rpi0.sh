#!/bin/sh

cd /home/bw/sel

mydate()  { date +%d%b%H:%M ; }

msg2(){ echo "$(mydate) geen internet verbinding, rebooting in 8 minuten"; }
msg3(){ echo "$(mydate) lokale tijd is niet in sync, rebooting in 8 minuten"; }
msg4(){ echo "$(mydate) centrale server is niet beschikbaar, rebooting in 8 minuten"; }
msg5(){ echo "$(mydate) lukt niet de centrale shared folder te koppelen, rebooting in 8 min"; }
msg7(){ echo "$(mydate) using bu pics"; }
msg8(){ echo "$(mydate) geen nieuwe pictures gevonden"; }

picsnr()  { ls $1 | wc -l ; }                                           # usage: picsnr pics 
noGoogle(){ ping -c 1 www.google.com > /dev/null ; }
noRpi4()  { ping -c 1 $rpi4ip &> /dev/null ; }
myreboot(){ echo $1; sleep 480; doas reboot; sleep 60; }
hmToMin() { min=$(echo $1 | cut -d: -f2); hrs=$(echo $1 | cut -d: -f1); echo $((hrs * 60 + min)) ; }
mGoogle() { hmToMin $(curl -sI www.google.com | grep '^Date:' | cut -d" " -f6 | cut -c 1-5) ; }
mRpi0()   { hmToMin $(date -u +%H:%M) ; }
gt2min()  { C=$1; [ $C -lt 0 ] && C=$((-C)); [ $C -gt 2 ] && echo false || echo true ; }
myMount() { doas ./remount.sh 2> /dev/null ; }
noPub()   { [ "$(ls pics2/picst)" = "" ] && echo false || echo true ; }
noChrony(){ doas ./retime.sh > /dev/null ; }

noPics()  { [ $(picsnr pics) -lt 2 ] && cp picsbu/T* pics && msg7; }    # pics leeg dan cp bu pics)
noInet()  { noGoogle || noGoogle || (msg2 && myreboot) ; }              # check internet max twice else reboot
noTimeH() { A=$(mGoogle); B=$(mRpi0); C=$((A-B)); gt2min $C ; }         # is locale tijd in sync (delta < 2 min)
noTimeC() { $(noTimeH) || (noChrony && noTimeH); }                      # als tijd niet ok restart chrony
noTime()  { $(noTimeC) || $(noTimeC) || (msg3 && myreboot) ; }          # locale tijd niet in sync, then reboot
noServer(){ noRpi4 || noRpi4 || (msg4 && myreboot) ; }                  # no central rpi4 twice, then reboor 
noShare() { $(noPub) || myMount || myMount || (msg5 && myreboot) ; }    # if no Public folder twice then reboot

rpi4whip1(){ myip=$( ip address | grep 192 | cut -d. -f3 ); 
           [ $myip -eq 178 ] && rpi4ip="192.168.178.80" || rpi4ip="192.168.2.80" ; }

rpi4whip() { rpi4ip=$(echo $(avahi-resolve-host-name -4 alp.local) | cut -d" " -f2); }

mainPi01(){ noPics; noInet; noTime; rpi4whip; noServer; noShare; }      # noTime alleen at boot?
mainPi02(){ noPics; noInet;         rpi4whip; noServer; noShare; }      # noTime alleen at boot?

main(){ [ "$1" = "atboot" ] && mainPi01 || mainPi02 ; }

main

# doas mount -t cifs -o guest //$rpi4ip/pics3 /home/bw/sel/pics2
# noTime alleen at boot?
# rpi4ip is hier de 80 aanpassen voor Lwb?

