#!/bin/sh

# reboot at 8 hr, then do first round (start feh):

cd /home/bw/sel
sh rpi0.sh >> logs/bootlog 2>&1                # checkt pics, internet, tijd, rpi4ip, server, share 
sh rpi0first.sh >> logs/bootlog 2>&1           # checks reboot, checs prev proces, starts stops feh
sh rpi0cpNewPics.sh >> logs/bootlog 2>&1       # checks for 5 minutes if new pictures arrive and copies or msg
sh rpi0first.sh >> logs/bootlog 2>&1           # checks reboot, checs prev proces, starts stops feh


# xrandr overall uithalen fixed width en height 1920x1080
