#!/bin/sh

cd /home/bw/sel

mydate()  { date +%d%b%H:%M ; }

mymsg(){ echo "$(mydate) geen nieuwe pictures gevonden"; }

clearCp() { rm pics/* ; echo "$newest" | xargs -I {} cp {} pics ; }
cpNwPics(){ newPics; [ -n "$newest" ] &&  clearCp $newest ; }           # if new pics found copy to sel/pics
newPics1(){ find pics2/picst -type f -name "T*.png" -mmin -8 ; }
newPics2(){ newest=$(newPics1); [ -n "$newest" ] || (sleep 60 && return 1) ; }
newPics() { newPics2 || newPics2 || newPics2 || newPics2 || newPics2 || newPics2 || newPics2 || mymsg; }

cpDone()  { echo -n "$(mydate) cc newpics done "; }
newLine() { [ $(date +%M) -ge 45 ] && echo ""; }

main1()    { cpNwPics; cpDone; newLine; }
main()    { cpNwPics; cpDone; }

main
