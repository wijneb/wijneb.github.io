#      #!/bin/sh

apk update
apk upgrade
apk add nano xterm \
  font-terminus font-awesome \
  font-dejavu openbox firefox \
  pcmanfm mousepad python3 \
  xfce4-terminal dbus py3-pip \
  dbus-x11 lightdm-gtk-greeter \
  geckodriver \
  xdotool avahi curl xrandr feh xset \
  xf86-video-fbdev cifs-utils

addgroup bw input
addgroup bw video

cd /home/bw/
echo "exec openbox-session" > /home/bw/.xinitrc 
mkdir .config
cp -r /etc/xdg/openbox /home/bw/.config/openbox
chown -R bw:bw /home/bw

mkdir sel
cd sel
su bw
python3 -m venv /home/bw/sel/venv
source /home/bw/sel/venv/bin/activate
pip install selenium #  --break-system-packages 

doas rc-update add avahi-daemon
doas rc-update add lightdm 
doas rc-update add dbus 

doas rc-service dbus start 
doas rc-service lightdm start 
doas rc-service avahi-daemon start

#PATH=$PATH:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
#mycron 
#su - bw -c /home/bw/sel/rpi015min.sh
#/etc/doas.d/doas.conf 
#permit nopass bw as root
#sudo chmod 0644 /etc/doas.d/doas.conf
#sudo chown root:root /etc/doas.conf
#=> permit nopass bw cmd ./remount.sh
#=> ~/sel/remount.sh => #!/bin/sh 
#=> rpi4ip=$(echo $(avahi-resolve-host-name -4 alp.local) | cut -d" " -f2)
#=> mount -t cifs -o guest //$rpi4ip/pics3 /home/bw/sel/pics2
#=> permit nopass bw cmd ./retime.sh 
#=> ~/sel/retime.sh #!/bin/sh rc-service chronyd restart
#=> permit nopass bw cmd reboot
#in fun3.sh grep -i ^date
#in fun3 HT HI en HE ipv 3x HI
#toch venv, zonder werkt niet in cron
#doas nano /etc/lightdm/lightdm.conf
#autologin-user=bw
#autologin-session=openbox
#add firefox location to pyscript
#options = FirefoxOptions()
#options.add_argument("--headless")
#options.add_argument("--kiosk")  # Enables full-screen mode
#options.binary_location = r'/usr/bin/firefox'  
#usercfg.txt => disable_overscan=1



