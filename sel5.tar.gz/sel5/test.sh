#!/bin/sh

which echo
which curl
which mount
which reboot
which rc-service

echo "1 $(whoami) $(date)" # >> /home/bw/sel/logs/mylog 2>&1
echo "2 hello bart"# >> /home/bw/sel/logs/mylog 2>&1
echo "4 $(whoami)" # >> /home/bw/sel/logs/mylog 2>&1

