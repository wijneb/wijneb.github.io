#!/bin/sh
nano /etc/doas.d/doas.conf

# doas ./redoas.sh   without passwd

# permit nopass bw cmd ./redoas.sh   in /etc/doas.d/doas.conf
