#!/bin/sh

rpi4ip=$(echo $(avahi-resolve-host-name -4 alp.local) | cut -d" " -f2)

mount -t cifs -o guest //$rpi4ip/pics3 /home/bw/sel/pics2


# doas ./remount.sh   without passwd

# permit nopass bw cmd ./remount.sh   in /etc/doas.d/doas.conf
