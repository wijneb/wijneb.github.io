#!/bin/sh

apk update && apk add python3 py3-pip geckodriver

mkdir /home/bw/sel
mkdir /home/bw/sel/pics
cd /home/bw/sel

python3 -m venv /home/bw/sel/venv
source /home/bw/sel/venv/bin/activate
pip install selenium

echo "permit nopass bw as root cmd /usr/bin/rc-service args chronyd restart" >> /etc/doas.d/doas.conf



