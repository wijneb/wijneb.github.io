#!/bin/sh 
# myalp.sh
# set variables (this scope only)
    UU=bw; PW=abc; HB=home/$UU
#obinstall alpine
    apk update
    apk add --no-cache openbox doas feh nano pcmanfm firefox \
    xrdp xorgxrdp xorg-server xterm terminus-font mousepad sxhkd \
    dbus dbus-x11 font-dejavu font-awesome xfce4-terminal \
    gtk+3.0 rofi tar wmutils adwaita-icon-theme adw-gtk3
#adduser
    useradd -m $UU; addgroup wheel; 
    echo "$UU:$PW" | chpasswd; adduser $UU wheel 
    echo "permit persist :wheel" > /etc/doas.conf

cd /tmp/rdpconfigs/
# make install wmutils
    cd .wmutils_core; make; make install; cd ..
#getbackground
    mv .paris.jpg /$HB/.paris.jpg
#obconf
    mv .config /$HB/.config
#xsession
    mv .xsession /$HB/.xsession
# wmutilsbin
    mv .local /$HB/.local
# theming
    mv .themes /$HB/.themes
# bash_aliases
    mv .bash_aliases /$HB/.bash_aliases
cd /

#wrap_up
    chown -R $UU:$UU /home/$UU

# xcb?
