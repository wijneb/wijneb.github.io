#!/bin/sh 
# myObDeb.sh
# set variables (this scope only)
    UU=bw; PW=abc; HB=home/$UU
#obinstall
    apt-get update; DEBIAN_FRONTEND=noninteractive \
    apt-get install -y openbox doas curl feh nano pcmanfm \
    xrdp xterm  xfce4-terminal mousepad dbus dbus-x11 firefox-esr \
    fonts-terminus fonts-dejavu fonts-font-awesome sxhkd \
    apt-utils make gcc libxcb-util-dev libxcb-cursor-dev \
    gir1.2-gtk-3.0 rofi
#adduser
    useradd -m $UU; addgroup wheel; 
    echo "$UU:$PW" | chpasswd; adduser $UU wheel 
    echo "permit persist :wheel" > /etc/doas.conf

cd /tmp/rdpconfigs/
# make install wmutils
    cd .wmutils_core; make; make install; cd ..
#getbackground
    mv .paris.jpg /$HB/.paris.jpg
#obconf
    mv .config /$HB/.config
#xsession
    mv .xsession /$HB/.xsession
# wmutilsbin
    mv .local /$HB/.local
# theming
    mv .themes /$HB/.themes
# bash_aliases
    mv .bash_aliases /$HB/.bash_aliases
cd /

#wrap_up
    chown -R $UU:$UU /home/$UU

# xcb?
