#!/bin/sh

 if rc-service chronyd status | grep -q "started"
    then echo "chronyd is started correctly"
    else rc-service chronyd restart; sleep 5
 fi

apk update && apk add python3 py3-pip

mkdir /home/bw/sel
mkdir /home/bw/sel/pics
cd /home/bw/sel

python3 -m venv /home/bw/sel/venv
source /home/bw/sel/venv/bin/activate
pip install selenium

WIDTH=xrandr | awk '/\*\+/ {print $1}'| awk -Fx '{print $1}'
HEIGHT=xrandr | awk '/\*\+/ {print $1}'| awk -Fx '{print $2}'
export WIDTH
export HEIGHT

echo "permit nopass bw as root cmd /usr/bin/rc-service args chronyd restart" >> /etc/doas.d/doas.conf



