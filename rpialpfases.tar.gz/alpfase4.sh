#!/bin/sh

cat <<EOF > /home/bw/sel/bawalldias.sh

#!/bin/sh

url1=https://trackman.page.link/ERdao;  pic1=pics/longest7dagen.png;   time=20;
url2=https://trackman.page.link/95pmR;  pic2=pics/longest30dagen.png;  time2=20;
url3=https://trackman.page.link/X31Rw;  pic3=pics/bullseye7dagen.png;  time3=20;
url4=https://trackman.page.link/daXw2;  pic4=pics/bullseye30dagen.png; time4=20;

source /home/bw/sel/venv/bin/activate

makedia() {
    python snap.py
}

alldias() {
    for i in $(seq 4); do
        eval URLX=\$url$i
        eval PICX=\$pic$i
        export URLX
        export PICX
        makedia
    done
}

main() {
    feh --fullscreen --slideshow-delay 5 -R 20 pics &
    while true; do
        alldias
        sleep 300
    done
}

main

EOF

cat <<EOF > /home/bw/sel/snap.py

import os
import time
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium import webdriver

picx = os.getenv('PICX')
urlx = os.getenv('URLX')
wdth = os.getenv('WIDTH')
hght = os.getenv('HEIGHT')

#print(f'PICX: {picx}')
#print(f'URLX: {urlx}')

options = FirefoxOptions()
options.add_argument("--headless")
options.add_argument("--kiosk")  # Enables full-screen mode

service = FirefoxService(executable_path='/usr/bin/geckodriver')
driver = webdriver.Firefox(service=service, options=options)
driver.set_window_size(wdth, hght)
driver.get(urlx)

time.sleep(5)  # Wait for 5 seconds
driver.save_screenshot(picx)
driver.quit()

EOF