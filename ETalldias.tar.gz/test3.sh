#!/bin/sh

myfile="hal_1.ini"
myurl="https://www.leeuwenbergh.nl/infoscreens/hal_1.ini"

source /home/bw/sel/venv/bin/activate

WIDTH=$(xrandr 2>/dev/null | grep "0.00" | awk -Fx '{print $1}')
HEIGHT=$(xrandr 2>/dev/null | grep "0.00" | awk -Fx '{print $2}' | awk '{print $1}')
export WIDTH; export HEIGHT

readinifile() {
    if [ -f $myfile ]; then rm $myfile; fi; wget -q $myurl
    T_urls=$(cat $myfile | grep T_URL | awk -F= '{print $2}')
    T_pics=$(cat $myfile | grep T_TIT | awk -F= '{print $2}')
    E_urls=$(cat $myfile | grep E_URL | awk -F= '{print $2}')
    E_pics=$(cat $myfile | grep E_TIT | awk -F= '{print $2}')
    Delays=$(cat $myfile | grep GENER | awk -F= '{print $2}')
}

getUrls() {
    i=0  # Initialize counter voor urls
    for url in $Xurls; do
        i=$((i + 1))
        eval url$i=\$url
    done
    xnr=$i
}

getPicnames() {
    j=0  # Initialize counter voor pics
    for pic in $Xpics; do
        j=$((j+ 1))
        eval pic$j=\$pic
    done
}

getUrlsNames() {
    getUrls; getPicnames
}

test() {
i=0  # Initialize counter for urls
for url in $Xurls; do
    i=$((i + 1))
    eval url$j=\$url
    echo $(eval echo \$url$j)
done
j=0  # Initialize counter for pics
for pic in $Xpics; do
    j=$((j + 1))
    eval pic$j="pics2/$pic"
    echo $(eval echo \$pic$j)
done

}

makeDias() {
    for i in $(seq $xnr); do
        eval URLX=\$url$i
        eval PICX=\$pic$i
        export URLX; #echo $URLX
        export PICX; #echo $PICX
        echo $i "doing Tmakedia"
        python snap.py; 
    done
}

readinifile
 Xurls=$T_urls; Xpics=$T_pics
 getUrlsNames
 makeDias

# test
#Xurls=$T_urls; Xpics=$T_pics
#for url in $Xurls; do echo $url; done
#for pic in $Xpics; do echo $pic; done


