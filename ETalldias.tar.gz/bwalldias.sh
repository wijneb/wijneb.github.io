
#!/bin/sh

url1="https://trackman.page.link/ERdao";  pic1=pics/longest7dagen.png;   time=20;
url2=https://trackman.page.link/95pmR;  pic2=pics/longest30dagen.png;  time2=20;
url3=https://trackman.page.link/X31Rw;  pic3=pics/bullseye7dagen.png;  time3=20;
url4=https://trackman.page.link/daXw2;  pic4=pics/bullseye30dagen.png; time4=20;

WIDTH=$(xrandr 2>/dev/null | grep "0.00" | awk -Fx '{print $1}')
HEIGHT=$(xrandr 2>/dev/null | grep "0.00" | awk -Fx '{print $2}' | awk '{print $1}')
export WIDTH
export HEIGHT

source /home/bw/sel/venv/bin/activate

makedia() {
    python snap.py
}

alldias() {
    for i in $(seq 4); do
        eval URLX=\$url$i
        eval PICX=\$pic$i
        export URLX
        export PICX
        makedia
    done
}

statusTrue() { 
    # date
    # echo "Wi-Fi and chronyd up and running" 
    alldias 
}

statusFalse() { 
    date 
    echo "reboot in 900 sec" 
    sleep 900 
    doas /sbin/reboot 
}

setWifiClockFlags(){
    #test if this works, 1 is ok 0 is not ok.
    WIFI_STATUS=$(ip link show wlan0 | grep "state UP" | wc -l)
    CHRONYD_STATUS=$(rc-service chronyd status | grep "started" | wc -l)
}

checkWifiAndClock(){
    setWifiClockFlags
    if [ $WIFI_STATUS -eq 1 ] && [ $CHRONYD_STATUS -eq 1 ]; then
        statusTrue
    else
        statusFalse
    fi
}

checkClock(){
    setWifiClockFlags
    if !([ $CHRONYD_STATUS -eq 1 ]); then 
        doas /sbin/rc-service chronyd restart
        sleep 10
    fi
}

main() {
    # rotate pics 10 sec delay and refresh every 60 seconds
    feh --fullscreen --slideshow-delay 10 -R 60 pics &
    # set mouse pointer below and to the right
    xdotool mousemove $WIDTH $HEIGHT
    # if clock not ok restart clock (chronyd)
    checkClock
    while true; do
        # if clock and wifi ok make pics, if not reboot in 15 min
        checkWifiAndClock
        sleep 300
    done
}

main