Xpics="'aa_ee' 'bb_ee' 'cc_ee' 'dd_ee'"
Ypics=$Xpics

myfile="hal_1.ini"
myurl="https://www.leeuwenbergh.nl/infoscreens/hal_1.ini"

readinifile() {
    if [ -f $myfile ]; then rm $myfile; fi; wget -q $myurl
    sed -i "s/dagen/dagen.png/g" $myfile
    T_urls=$(cat $myfile | grep T_URL | awk -F= '{print $2}')
    T_pics=$(cat $myfile | grep T_TIT | awk -F= '{print $2}')
    E_urls=$(cat $myfile | grep E_URL | awk -F= '{print $2}')
    E_pics=$(cat $myfile | grep E_TIT | awk -F= '{print $2}')
    Delays=$(cat $myfile | grep GENER | awk -F= '{print $2}')
}

readinifile

j=0  # Initialize counter for pics
for pic in $T_pics; do
    j=$((j + 1))
    eval pic$j="pics2/$pic"
    eval echo \$pic$j
done