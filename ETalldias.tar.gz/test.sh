Xpics="aa bb cc dd"

j=0  # Initialize counter for pics
for pic in $Xpics; do
    j=$((j + 1))
    eval pic$j="pics2/$pic"
    echo $(eval echo \$pic$j)
done
