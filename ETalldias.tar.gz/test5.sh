pics="hello bart wijne okido"

for pic in $pics; do
   echo $pic
   pic=${pic}.jpg
   echo $pic
done 