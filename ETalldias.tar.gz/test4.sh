
#!/bin/sh

#url1=https://trackman.page.link/ERdao;  pic1=pics/longest7dagen.png;   time=20;
#url2=https://trackman.page.link/95pmR;  pic2=pics/longest30dagen.png;  time2=20;
#url3=https://trackman.page.link/X31Rw;  pic3=pics/bullseye7dagen.png;  time3=20;
#url4=https://trackman.page.link/daXw2;  pic4=pics/bullseye30dagen.png; time4=20;

WIDTH=$(xrandr 2>/dev/null | grep "0.00" | awk -Fx '{print $1}')
HEIGHT=$(xrandr 2>/dev/null | grep "0.00" | awk -Fx '{print $2}' | awk '{print $1}')
export WIDTH
export HEIGHT

source /home/bw/sel/venv/bin/activate

myfile="hal_1.ini"
myurl="https://www.leeuwenbergh.nl/infoscreens/hal_1.ini"

readinifile() {
    if [ -f $myfile ]; then rm $myfile; fi; wget -q $myurl
    dos2unix $myfile; sed -i "s/dagen/dagen.png/g" $myfile
    T_urls=$(cat $myfile | grep T_URL | awk -F= '{print $2}')
    T_pics=$(cat $myfile | grep T_TIT | awk -F= '{print $2}')
    E_urls=$(cat $myfile | grep E_URL | awk -F= '{print $2}')
    E_pics=$(cat $myfile | grep E_TIT | awk -F= '{print $2}')
    Delays=$(cat $myfile | grep GENER | awk -F= '{print $2}')
}

getUrls() {
    echo "starting geturls"
    i=0  # Initialize counter voor urls
    for url in $Xurls; do
        i=$((i + 1))
        eval url$i=\$url
    done
    xnr=$i
}

getPicnames() {
    echo "starting getpics"
    j=0  # Initialize counter voor pics
    for pic in $Xpics; do
        j=$((j+ 1))
        eval pic$j="pics2/$pic"
    done
}

getUrlsNames() {
    getUrls; getPicnames
}

makedia() {
    python snap.py
}

alldias() {
    for i in $(seq 4); do
        eval URLX=\$url$i
        eval PICX=\$pic$i
        URLX=${URLX#\"}
        URLX=${URLX%\"}
        export URLX
        export PICX
        #makedia
    done
echo $URLX
echo $PICX
makedia
}



readinifile
Xurls=$T_urls; Xpics=$T_pics
getUrlsNames
alldias
#cat -v $myfile


#echo " "
#echo url4 : $url4 
#echo pic4 : $pic4


